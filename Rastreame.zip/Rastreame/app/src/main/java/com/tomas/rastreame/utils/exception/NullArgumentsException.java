package com.tomas.rastreame.utils.exception;

/**
 * Created by Tomas on 25/10/2015.
 */
public class NullArgumentsException extends Exception
{
    public NullArgumentsException(String  message)
    {
        super(message);
    }
}
